package com.and.test;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertArrayEquals;

public class SolutionTest {

    @Test
    public void test_Solution_Where_Input_Has_Numeric_Characters() {
        // Arrange
        String input = "236";
        String expectedResult = "632,623,362,326,263,236";

        // Act
        String actualResult = Solution.solution(input);

        // Assert
        Assert.assertEquals(expectedResult, actualResult);
    }

    @Test
    public void test_Solution_Where_Input_Has_Non_Numeric_Characters() {
        // Arrange
        String input = "A 3B2 C6D";
        String expectedResult = "632,623,362,326,263,236";

        // Act
        String actualResult = Solution.solution(input);

        // Assert
        Assert.assertEquals(expectedResult, actualResult);
    }

    @Test(expected = NumberFormatException.class)
    public void test_Solution_Where_Input_Has_Only_Non_Numeric_Characters_Raises_Exception() {

        // Arrange
        String input = "ABC";

        // Act
        Solution.solution(input);

    }

    @Test
    public void test_FindPermutations_Where_Input_Is_Valid() {

        // Arrange
        String input = "236";

        ArrayList<String> expectedResult = new ArrayList<>();
        expectedResult.add("236");
        expectedResult.add("326");
        expectedResult.add("362");
        expectedResult.add("263");
        expectedResult.add("623");
        expectedResult.add("632");

        // Act
        ArrayList<String> actualResult = Solution.findPermutations(input);

        // Assert
        assertArrayEquals(expectedResult.toArray(), actualResult.toArray());
    }

    @Test
    public void test_DescendingSortArrayList_Where_ArrayList_Is_Not_In_Order_Returns_Ordered_ArrayList() {
        // Arrange
        ArrayList<String> input = new ArrayList<>();
        input.add("326");
        input.add("236");
        input.add("263");
        input.add("362");
        input.add("632");
        input.add("623");

        ArrayList<String> expectedResult = new ArrayList<>();
        expectedResult.add("632");
        expectedResult.add("623");
        expectedResult.add("362");
        expectedResult.add("326");
        expectedResult.add("263");
        expectedResult.add("236");

        // Act
        Solution.descendingSortArrayList(input);

        // Assert
        assertArrayEquals(expectedResult.toArray(), input.toArray());

    }

    @Test
    public void test_FilterNumericCharacters_Where_There_Are_Only_Numeric_Characters_Returns_String_With_No_Changes() {
        // Arrange
        String input = "236";
        String expectedResult = "236";

        // Act
        String actualResult = Solution.filterNumericCharacters(input);

        // Assert
        Assert.assertEquals(expectedResult, actualResult);
    }

    @Test
    public void test_FilterNumericCharacters_Where_There_Are_Non_Numeric_Characters_Returns_String_With_Numeric_Characters_Only() {

        // Arrange
        String input = "“A 3B2 C6D";
        String expectedResult = "326";

        // Act
        String actualResult = Solution.filterNumericCharacters(input);

        // Assert
        Assert.assertEquals(expectedResult, actualResult);
    }

    @Test
    public void test_FilterNumericCharacters_Where_There_Are_Only_Non_Numeric_Characters_Returns_Empty_String() {

        // Arrange
        String input = "“A CD";
        String expectedResult = "";

        // Act
        String actualResult = Solution.filterNumericCharacters(input);

        // Assert
        Assert.assertEquals(expectedResult, actualResult);
    }
}