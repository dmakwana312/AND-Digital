package com.and.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Solution {

    /**
     * The following is the method where the solution shall be written
     */

    public static String solution(String input) throws NumberFormatException {

        // Filter input string to have only numbers
        String filterInput = filterNumericCharacters(input);

        // If filtered input is empty string, raise exception
        if (filterInput.equals("")) {
            throw new NumberFormatException("Input Is Not Valid");
        }

        // Find Permutations and sort in descending order
        ArrayList<String> result = findPermutations(filterInput);
        descendingSortArrayList(result);

        // Convert arraylist of results to comma separated string
        return String.join(",", result);
    }

    public static ArrayList<String> findPermutations(String input) {

        // If input is empty, return base result
        if (input.length() == 0) {
            ArrayList<String> baseResult = new ArrayList<>();
            baseResult.add("");
            return baseResult;
        }

        // Separate first character in input and rest of string
        char firstChar = input.charAt(0);
        String rest = input.substring(1);

        // Find all permutations of rest of string
        ArrayList<String> recResult = findPermutations(rest);

        // Empty arraylist to hold result
        ArrayList<String> result = new ArrayList<>();

        // For each result from recursive call, find all permutations with first character
        for (String str : recResult) {

            // Place the first character at all positions in str to get all permutation
            for (int j = 0; j <= str.length(); j++) {
                String newString = str.substring(0, j) + firstChar + str.substring(j);
                result.add(newString);
            }
        }

        // Return result
        return result;

    }

    // Sort arraylist in descending order
    public static void descendingSortArrayList(ArrayList<String> permutations) {
        permutations.sort(Collections.reverseOrder());
    }

    // Filter string to remove all non-numeric character
    public static String filterNumericCharacters(String input) {
        return input.replaceAll("[^0-9]", "");
    }

    public static void main(String args[]) {
        solution("326");
    }

}
